# Dat File Format

A C++ code snippet explaining how to load .dat file can be found bellow.

```
float sample_set[TILE_X][TILE_Y * TILE_SPP * TILE_DIM];

std::ifstream dat_in(blue_noise_file);

for (int i = 0; i < TILE_X; i++)
    for (int j = 0; j < TILE_Y; j++)
        for (int s = 0; s < TILE_SPP; s++)
            for (int d = 0; d < TILE_DIM; d++) {
                dat_in >> sample_set[i % TILE_X][(j % TILE_Y) * TILE_SPP * TILE_DIM + (s % TILE_SPP) * TILE_DIM + (d % TILE_DIM)];
            }
dat_in.close();
```

In case you experiance any issues or have any questions, please contact "corentin.salaun@gmail.com".
